package net.example.shulkinventory;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.example.shulkinventory.network.ShulkInventoryPayload;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ShulkInventoryAddon implements ModInitializer {

    public static final String MOD_ID = "shulk_inventory_addon";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Shulk Inventory Addon initializing...");

        PayloadTypeRegistry.playC2S().register(ShulkInventoryPayload.ID, ShulkInventoryPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(ShulkInventoryPayload.ID, (payload, context) -> {
            context.server().execute(() -> {
                var player = context.player();
                ShulkInventoryHelper.handleSlotChangeFromClient(player, payload.slot(), payload.stack());
            });
        });

        LOGGER.info("Shulk Inventory Addon initialized.");
    }
}
