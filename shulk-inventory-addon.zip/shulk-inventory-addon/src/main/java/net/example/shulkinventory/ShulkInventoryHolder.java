package net.example.shulkinventory;

import net.minecraft.item.ItemStack;

/**
 * Mixed into {@code PlayerScreenHandler} to track whether the Shulk extra
 * slots are currently injected and to allow reading them back.
 */
public interface ShulkInventoryHolder {

    /** Returns true if the extra Shulk slots are currently injected into this handler. */
    boolean shulk_hasExtraSlots();

    /** Gets the extra-slot inventory slot count. */
    int shulk_getExtraSlotCount();

    /** Returns the {@link ItemStack} at the given extra-slot index. */
    ItemStack shulk_getExtraStack(int index);

    /** Sets the {@link ItemStack} at the given extra-slot index. */
    void shulk_setExtraStack(int index, ItemStack stack);

    /** Called when the screen handler is opened to refresh slots from the Origins power. */
    void shulk_refreshExtraSlots();
}
