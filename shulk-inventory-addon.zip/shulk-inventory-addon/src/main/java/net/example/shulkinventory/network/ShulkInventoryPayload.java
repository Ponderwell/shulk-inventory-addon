package net.example.shulkinventory.network;

import net.example.shulkinventory.ShulkInventoryAddon;
import net.minecraft.item.ItemStack;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/**
 * Sent by the client to inform the server that the player changed one of the
 * extra Shulk inventory slots visible in the player's inventory screen.
 */
public record ShulkInventoryPayload(int slot, ItemStack stack) implements CustomPayload {

    public static final CustomPayload.Id<ShulkInventoryPayload> ID =
            new CustomPayload.Id<>(Identifier.of(ShulkInventoryAddon.MOD_ID, "shulk_slot_change"));

    public static final PacketCodec<RegistryByteBuf, ShulkInventoryPayload> CODEC =
            PacketCodec.of(ShulkInventoryPayload::write, ShulkInventoryPayload::read);

    private static ShulkInventoryPayload read(RegistryByteBuf buf) {
        int slot = buf.readVarInt();
        ItemStack stack = ItemStack.PACKET_CODEC.decode(buf);
        return new ShulkInventoryPayload(slot, stack);
    }

    private void write(RegistryByteBuf buf) {
        buf.writeVarInt(slot);
        ItemStack.PACKET_CODEC.encode(buf, stack);
    }

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
