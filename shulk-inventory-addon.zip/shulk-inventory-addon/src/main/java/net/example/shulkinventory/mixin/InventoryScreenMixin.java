package net.example.shulkinventory.mixin;

import net.example.shulkinventory.ShulkInventoryHelper;
import net.example.shulkinventory.ShulkInventoryHolder;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.AbstractInventoryScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Client-side mixin on {@link InventoryScreen}.
 *
 * <p>Draws a 3×3 grid of slot backgrounds in the top-left area of the
 * inventory screen when the player is a Shulk.  The slots themselves are
 * registered in {@link PlayerScreenHandlerMixin}; this mixin only handles
 * the visual presentation.
 *
 * <p>The vanilla inventory screen background is 176 × 166 px, rendered from
 * ({@code x},{@code y}).  The armour slots column occupies x = [7, 25] with
 * the 4 armour slots at y = 8, 26, 44, 62.  We place our 9 extra slots in a
 * 3-column × 3-row grid at:
 *   - col 0: x + 9
 *   - col 1: x + 27
 *   - col 2: x + 45
 *   - row 0: y + 8
 *   - row 1: y + 26
 *   - row 2: y + 44
 * This means they overlap the space where the crafting 2×2 grid would be in
 * the survival inventory (top right: x+98, y+18) — no, we intentionally
 * keep them on the LEFT where the armour slots are, in a separate column.
 *
 * <p>Actually the cleanest layout that doesn't overlap anything vanilla is to
 * expand the screen width slightly and place the 9 extra slots to the right
 * of the player model.  We shift the "right side" sections 58 px to the right
 * and fill the gap with a 3×3 slot grid.  This keeps the vanilla layout intact.
 */
@Environment(EnvType.CLIENT)
@Mixin(InventoryScreen.class)
public abstract class InventoryScreenMixin
        extends AbstractInventoryScreen<PlayerScreenHandler> {

    // Vanilla inventory texture
    @Unique
    private static final Identifier INVENTORY_TEXTURE =
            Identifier.ofVanilla("textures/gui/container/inventory.png");

    // Small generic slot texture (the empty slot sprite used by vanilla)
    @Unique
    private static final Identifier SLOT_TEXTURE =
            Identifier.ofVanilla("textures/gui/sprites/container/slot.png");

    protected InventoryScreenMixin(PlayerScreenHandler handler,
                                    PlayerInventory inventory,
                                    Text title) {
        super(handler, inventory, title);
    }

    // ── Lifecycle ────────────────────────────────────────────────────────────

    /**
     * When the screen initialises, expand the background width if the player
     * is a Shulk so that the 9 extra slot backgrounds have room.
     */
    @Inject(method = "init", at = @At("TAIL"))
    private void shulk$onInit(CallbackInfo ci) {
        if (isShulk()) {
            // We add 58 px on the right side (3 columns × 18 px + 4 px padding)
            this.backgroundWidth = 176 + 58;
            // Re-center after expanding
            this.x = (this.width - this.backgroundWidth) / 2;
        }
    }

    /**
     * After vanilla draws the inventory background, draw slot backgrounds for
     * each of the 9 extra Shulk slots on the right side of the screen.
     */
    @Inject(
        method = "drawBackground",
        at = @At("TAIL")
    )
    private void shulk$drawExtraSlotBackgrounds(DrawContext context,
                                                  float delta,
                                                  int mouseX,
                                                  int mouseY,
                                                  CallbackInfo ci) {
        if (!isShulk()) return;

        int panelX = this.x + 176 + 4;   // just to the right of the vanilla panel
        int panelY = this.y + 8;

        // Draw a small dark background panel behind the 9 extra slots
        // (same grey as the inventory panel: #8B8B8B approximately)
        context.fill(panelX - 4, panelY - 4,
                     panelX + 3 * 18 + 4, panelY + 3 * 18 + 4,
                     0xFF8B8B8B);

        // Draw each slot background (vanilla uses the slot sprite at 18×18 px)
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                int slotX = panelX + col * 18;
                int slotY = panelY + row * 18;
                context.drawGuiTexture(SLOT_TEXTURE, slotX - 1, slotY - 1, 18, 18);
            }
        }

        // Draw a small label above the panel
        context.drawText(this.textRenderer,
                Text.literal("Shell"),
                panelX + 4, panelY - 14,
                0x404040, false);
    }

    // ── Helper ───────────────────────────────────────────────────────────────

    @Unique
    private boolean isShulk() {
        if (this.client == null || this.client.player == null) return false;
        return ShulkInventoryHelper.hasShulkInventory(this.client.player) &&
               ((ShulkInventoryHolder) this.handler).shulk_hasExtraSlots();
    }
}
