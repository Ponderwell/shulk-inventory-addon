package net.example.shulkinventory.mixin;

import net.example.shulkinventory.ShulkInventoryHelper;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Prevents the Origins {@code InventoryPowerType} from opening its separate
 * 9-slot GUI when the player presses the primary-active power keybind,
 * because those slots are now always visible in the regular inventory screen.
 *
 * <p>Origins opens its inventory by sending a {@code OpenInventoryS2CPacket}
 * from the server when the keybind fires.  The cleanest intercept point is
 * {@code ServerPlayerEntity#openHandledScreen()} — if the screen being opened
 * is an Origins inventory factory, and the player has our addon active, we
 * cancel the open.
 *
 * <p>Because Origins internal classes may change, we intercept based on the
 * screen handler factory's class name rather than an instanceof check.
 */
@Mixin(ServerPlayerEntity.class)
public class ServerPlayerEntityMixin {

    @Inject(
        method = "openHandledScreen",
        at = @At("HEAD"),
        cancellable = true
    )
    private void shulk$interceptOriginInventoryOpen(
            net.minecraft.screen.NamedScreenHandlerFactory factory,
            org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable<java.util.OptionalInt> cir) {

        if (factory == null) return;

        ServerPlayerEntity self = (ServerPlayerEntity) (Object) this;

        // Only suppress if this player has the Shulk inventory power
        if (!ShulkInventoryHelper.hasShulkInventory(self)) return;

        // Check if the factory being opened is an Origins InventoryPowerType screen
        // (class name contains "InventoryPower" or the full Origins package path)
        String factoryClass = factory.getClass().getName();
        if (factoryClass.contains("apoli") && factoryClass.contains("nventory")) {
            // Suppress opening — the slots are already in the player inventory screen
            cir.setReturnValue(java.util.OptionalInt.empty());
        }
    }
}
