package net.example.shulkinventory;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Method;

/**
 * Utility class that bridges our addon with the Origins InventoryPowerType.
 *
 * <p>Origins stores the Shulk's extra 9 slots as an {@code InventoryPowerType}
 * (power id: {@code origins:shulker_inventory}). This helper retrieves the
 * {@code SimpleInventory} backing that power and lets us read/write its slots
 * so that our extra inventory GUI slots are kept in sync with what Origins
 * already persists.
 *
 * <p>All Origins access is done via reflection so we only need Origins on the
 * compile-time classpath as {@code modCompileOnly}, not as a hard runtime dep
 * that would crash if Origins is absent. If Origins is absent the helper
 * simply returns empty stacks / no-ops.
 */
public final class ShulkInventoryHelper {

    private static final Logger LOGGER = LoggerFactory.getLogger(ShulkInventoryAddon.MOD_ID);

    /** The Origins power id for the Shulk's extra inventory. */
    public static final Identifier SHULKER_INVENTORY_POWER_ID =
            Identifier.of("origins", "shulker_inventory");

    // ── Lazily-resolved reflection handles ─────────────────────────────────

    private static volatile boolean resolved = false;
    private static Method getPowerMethod;        // PowerHolderComponent.getPower(Identifier)
    private static Method getInventoryMethod;    // InventoryPowerType.getInventory()
    private static Method invGetStackMethod;     // SimpleInventory.getStack(int)
    private static Method invSetStackMethod;     // SimpleInventory.setStack(int, ItemStack)
    private static Method invSizeMethod;         // SimpleInventory.size()
    private static Class<?> componentClass;

    private ShulkInventoryHelper() {}

    // ── Public API ──────────────────────────────────────────────────────────

    /** Returns true when the player currently has the Shulk origin inventory power. */
    public static boolean hasShulkInventory(PlayerEntity player) {
        return getPowerInventory(player) != null;
    }

    /** Returns the number of extra slots (9 when the power is present, else 0). */
    public static int getExtraSlotCount(PlayerEntity player) {
        Object inv = getPowerInventory(player);
        if (inv == null) return 0;
        try {
            return (int) invSizeMethod.invoke(inv);
        } catch (Exception e) {
            return 0;
        }
    }

    /** Gets the {@link ItemStack} at the given extra-slot index from the Origins power. */
    public static ItemStack getStack(PlayerEntity player, int slot) {
        Object inv = getPowerInventory(player);
        if (inv == null) return ItemStack.EMPTY;
        try {
            return (ItemStack) invGetStackMethod.invoke(inv, slot);
        } catch (Exception e) {
            return ItemStack.EMPTY;
        }
    }

    /** Writes an {@link ItemStack} into the Origins power inventory at the given slot. */
    public static void setStack(PlayerEntity player, int slot, ItemStack stack) {
        Object inv = getPowerInventory(player);
        if (inv == null) return;
        try {
            invSetStackMethod.invoke(inv, slot, stack);
        } catch (Exception e) {
            LOGGER.warn("Failed to write Shulk inventory slot {}: {}", slot, e.getMessage());
        }
    }

    /**
     * Called on the server side when a {@link net.example.shulkinventory.network.ShulkInventoryPayload}
     * arrives from the client.
     */
    public static void handleSlotChangeFromClient(PlayerEntity player, int slot, ItemStack stack) {
        if (!hasShulkInventory(player)) return;
        int size = getExtraSlotCount(player);
        if (slot < 0 || slot >= size) return;
        setStack(player, slot, stack);
    }

    // ── Reflection internals ────────────────────────────────────────────────

    private static void ensureResolved() {
        if (resolved) return;
        synchronized (ShulkInventoryHelper.class) {
            if (resolved) return;
            try {
                resolveReflection();
            } catch (Exception e) {
                LOGGER.warn("Could not resolve Origins reflection handles — Shulk inventory integration disabled. ({})", e.getMessage());
            } finally {
                resolved = true;
            }
        }
    }

    private static void resolveReflection() throws Exception {
        // PowerHolderComponent (Cardinal Components component attached to players)
        componentClass = Class.forName("io.github.apace100.apoli.component.PowerHolderComponent");

        // PowerHolderComponent.KEY (the component key, needed to get the component from the player)
        // In Apoli the component is accessed via PowerHolderComponent.KEY.get(entity)
        var keyField = componentClass.getDeclaredField("KEY");
        keyField.setAccessible(true);
        // The KEY is a ComponentKey<PowerHolderComponent>; we call .get(entity) on it
        // We capture this as a generic Object and invoke it reflectively.

        // PowerHolderComponent#hasPower(PowerType) — but we'll use #getPower(Identifier)
        // Actually Apoli API: PowerHolderComponent.getPowers(class) or getPower(PowerType)
        // Simplest: use the static getPower helper
        // Check if there's a getPower(LivingEntity, Identifier) static utility
        // In newer Apoli: PowerHolderComponent.getPowers(entity) → List; or
        //   PowerHolderComponent.KEY.get(entity).hasPower(powerType)
        // We'll walk through: KEY.get(player) → PowerHolderComponent instance
        //   then call hasPower(PowerType) where we look up the PowerType by id.

        // Simplest path: use PowerHolderComponent.KEY.get(entity).getPowers(InventoryPowerType.class)
        getPowerMethod = componentClass.getMethod("getPowers", Class.class);

        // InventoryPowerType
        Class<?> inventoryPowerClass = Class.forName("io.github.apace100.apoli.power.type.InventoryPowerType");
        // InventoryPowerType#getInventory() → SimpleInventory
        getInventoryMethod = inventoryPowerClass.getMethod("getInventory");

        // SimpleInventory from Minecraft
        Class<?> simpleInvClass = Class.forName("net.minecraft.inventory.SimpleInventory");
        invGetStackMethod = simpleInvClass.getMethod("getStack", int.class);
        invSetStackMethod = simpleInvClass.getMethod("setStack", int.class, ItemStack.class);
        invSizeMethod     = simpleInvClass.getMethod("size");

        LOGGER.info("Origins reflection handles resolved successfully.");
    }

    /**
     * Returns the {@code SimpleInventory} backing the Shulk power, or
     * {@code null} if Origins is not present / player lacks the power.
     */
    @SuppressWarnings("unchecked")
    private static Object getPowerInventory(PlayerEntity player) {
        ensureResolved();
        if (getPowerMethod == null || getInventoryMethod == null) return null;
        try {
            // Get the PowerHolderComponent attached to the player via the Cardinal Components KEY
            var keyField = componentClass.getDeclaredField("KEY");
            keyField.setAccessible(true);
            Object key = keyField.get(null);

            // ComponentKey<T>.get(ComponentProvider) → T
            Method getFromKey = key.getClass().getMethod("get", Object.class);
            Object component = getFromKey.invoke(key, player);
            if (component == null) return null;

            // PowerHolderComponent#getPowers(Class<T>) → List<T>
            Class<?> inventoryPowerClass = Class.forName("io.github.apace100.apoli.power.type.InventoryPowerType");
            java.util.List<?> powers = (java.util.List<?>) getPowerMethod.invoke(component, inventoryPowerClass);
            if (powers == null || powers.isEmpty()) return null;

            // Use the first InventoryPowerType found (the Shulk origin only has one)
            Object powerType = powers.get(0);
            return getInventoryMethod.invoke(powerType);
        } catch (Exception e) {
            // Silently return null; player doesn't have the power or Origins is not loaded
            return null;
        }
    }
}
