package net.example.shulkinventory.screen;

import net.example.shulkinventory.ShulkInventoryHelper;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.Slot;

/**
 * A custom {@link Slot} that delegates all item storage to the Origins
 * {@code InventoryPowerType}'s {@code SimpleInventory} for the given player.
 *
 * <p>This slot wraps a lightweight {@link ShulkSlotInventory} which itself
 * proxies calls through {@link ShulkInventoryHelper} using reflection so we
 * don't need a hard dependency on Origins internals.
 */
public class ShulkSlot extends Slot {

    private final PlayerEntity player;
    private final int powerSlotIndex;

    public ShulkSlot(PlayerEntity player, int powerSlotIndex, int x, int y) {
        super(new ShulkSlotInventory(player, powerSlotIndex), powerSlotIndex, x, y);
        this.player = player;
        this.powerSlotIndex = powerSlotIndex;
    }

    @Override
    public boolean canInsert(ItemStack stack) {
        return ShulkInventoryHelper.hasShulkInventory(player);
    }

    @Override
    public boolean canTakeItems(PlayerEntity playerEntity) {
        return ShulkInventoryHelper.hasShulkInventory(player);
    }

    @Override
    public ItemStack getStack() {
        return ShulkInventoryHelper.getStack(player, powerSlotIndex);
    }

    @Override
    public void setStack(ItemStack stack) {
        ShulkInventoryHelper.setStack(player, powerSlotIndex, stack);
        markDirty();
    }

    @Override
    public boolean hasStack() {
        return !getStack().isEmpty();
    }

    /** Thin {@link Inventory} wrapper so the vanilla {@link Slot} superclass is happy. */
    private static class ShulkSlotInventory implements Inventory {

        private final PlayerEntity player;
        private final int size;

        ShulkSlotInventory(PlayerEntity player, int size) {
            this.player = player;
            this.size = size;
        }

        @Override public int size() { return size; }
        @Override public boolean isEmpty() { return false; }

        @Override
        public ItemStack getStack(int slot) {
            return ShulkInventoryHelper.getStack(player, slot);
        }

        @Override
        public ItemStack removeStack(int slot, int amount) {
            ItemStack current = ShulkInventoryHelper.getStack(player, slot);
            if (current.isEmpty()) return ItemStack.EMPTY;
            ItemStack split = current.split(amount);
            ShulkInventoryHelper.setStack(player, slot, current);
            return split;
        }

        @Override
        public ItemStack removeStack(int slot) {
            ItemStack stack = ShulkInventoryHelper.getStack(player, slot);
            ShulkInventoryHelper.setStack(player, slot, ItemStack.EMPTY);
            return stack;
        }

        @Override
        public void setStack(int slot, ItemStack stack) {
            ShulkInventoryHelper.setStack(player, slot, stack);
        }

        @Override public void markDirty() {}
        @Override public boolean canPlayerUse(PlayerEntity player) { return true; }
        @Override public void clear() {}
    }
}
