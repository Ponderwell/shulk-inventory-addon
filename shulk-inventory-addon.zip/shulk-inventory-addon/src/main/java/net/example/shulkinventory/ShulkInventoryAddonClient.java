package net.example.shulkinventory;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.example.shulkinventory.network.ShulkInventoryPayload;

@Environment(EnvType.CLIENT)
public class ShulkInventoryAddonClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        PayloadTypeRegistry.playC2S().register(ShulkInventoryPayload.ID, ShulkInventoryPayload.CODEC);
    }
}
