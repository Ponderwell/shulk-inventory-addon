package net.example.shulkinventory.mixin;

import net.example.shulkinventory.ShulkInventoryHelper;
import net.example.shulkinventory.ShulkInventoryHolder;
import net.example.shulkinventory.screen.ShulkSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.slot.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;

/**
 * Injects 9 extra {@link ShulkSlot}s into the {@link PlayerScreenHandler}
 * whenever the owning player has the Origins Shulk inventory power.
 *
 * <p>Layout in the inventory screen (pixels):
 * The vanilla inventory screen is 176 × 166 px.  We render 9 extra slots
 * in a single row below the armour column on the left side:
 *   row y = 8,  first slot x = 9  (matching armour-slot column)
 * so slots are placed at (9 + n*18, 8) in screen coordinates.
 * In practice we tile them the same way the crafting output area works —
 * the mixin only registers slots; the {@link net.example.shulkinventory.mixin.InventoryScreenMixin}
 * handles rendering the extra background squares on the client.
 *
 * <p>Slot indices in the handler start after all vanilla slots.
 * Vanilla PlayerScreenHandler adds slots at indices 0-45 (crafting 0-4,
 * armour 5-8, main inventory 9-35, hotbar 36-44, offhand 45 → 46 total).
 * Our 9 extra slots are added at indices 46-54.
 */
@Mixin(PlayerScreenHandler.class)
public abstract class PlayerScreenHandlerMixin implements ShulkInventoryHolder {

    // ── Vanilla shadows ─────────────────────────────────────────────────────

    @Shadow public abstract Slot getSlot(int index);

    // ── Unique fields ───────────────────────────────────────────────────────

    @Unique private PlayerEntity shulk$player;
    @Unique private final List<ShulkSlot> shulk$extraSlots = new ArrayList<>();
    @Unique private boolean shulk$slotsAdded = false;

    // ── Injection ───────────────────────────────────────────────────────────

    /**
     * Captures the player reference immediately after the vanilla constructor
     * finishes populating slots, then conditionally adds the Shulk slots.
     *
     * <p>We inject at TAIL so that the vanilla slot list is fully populated
     * before we append to it.
     */
    @Inject(
        method = "<init>(Lnet/minecraft/entity/player/PlayerInventory;ZLnet/minecraft/entity/player/PlayerEntity;)V",
        at = @At("TAIL")
    )
    private void shulk$onInit(PlayerInventory playerInventory, boolean onServer, PlayerEntity player,
                               CallbackInfo ci) {
        this.shulk$player = player;
        shulk$tryAddSlots();
    }

    // ── ShulkInventoryHolder interface implementation ───────────────────────

    @Override
    @Unique
    public boolean shulk_hasExtraSlots() {
        return shulk$slotsAdded && !shulk$extraSlots.isEmpty();
    }

    @Override
    @Unique
    public int shulk_getExtraSlotCount() {
        return shulk$extraSlots.size();
    }

    @Override
    @Unique
    public ItemStack shulk_getExtraStack(int index) {
        if (index < 0 || index >= shulk$extraSlots.size()) return ItemStack.EMPTY;
        return shulk$extraSlots.get(index).getStack();
    }

    @Override
    @Unique
    public void shulk_setExtraStack(int index, ItemStack stack) {
        if (index < 0 || index >= shulk$extraSlots.size()) return;
        shulk$extraSlots.get(index).setStack(stack);
    }

    @Override
    @Unique
    public void shulk_refreshExtraSlots() {
        // Nothing needed — ShulkSlot reads live from the Origins inventory every call
    }

    // ── Private helpers ─────────────────────────────────────────────────────

    @Unique
    private void shulk$tryAddSlots() {
        if (shulk$player == null) return;
        if (!ShulkInventoryHelper.hasShulkInventory(shulk$player)) return;
        if (shulk$slotsAdded) return;

        int count = ShulkInventoryHelper.getExtraSlotCount(shulk$player);
        if (count <= 0) count = 9; // Default for Shulk origin

        /*
         * Slot screen positions must match what InventoryScreenMixin draws.
         * The extra panel starts at x=176+4=180, y=8 (relative to the screen
         * handler origin, which is the top-left corner of the inventory panel).
         * Each slot is 18 px wide, in a 3-column × 3-row grid.
         */
        for (int i = 0; i < count; i++) {
            int col = i % 3;
            int row = i / 3;
            // Positions are in screen-handler coordinate space (relative to panel origin)
            int x = 180 + col * 18;  // right of the vanilla panel
            int y = 8 + row * 18;
            ShulkSlot slot = new ShulkSlot(shulk$player, i, x, y);
            shulk$extraSlots.add(slot);
            addSlot(slot);
        }
        shulk$slotsAdded = true;
    }
}
